declare module "@salesforce/resourceUrl/CLWCP_Assets" {
    var CLWCP_Assets: string;
    export default CLWCP_Assets;
}
declare module "@salesforce/resourceUrl/ChatStyle" {
    var ChatStyle: string;
    export default ChatStyle;
}
